/*#include <SFML/Graphics.hpp>
#include <iostream>
#include <windows.h>
#include "strzelanie_player1.h"
#include "klasa_postac.h"

#include <vector>
#include <math.h>


using namespace sf;
using namespace std;
*/
