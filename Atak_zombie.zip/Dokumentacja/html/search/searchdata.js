var indexSectionsWithContent =
{
  0: "abcdghiklmnoprsuwz",
  1: "gsz",
  2: "acikmpsw",
  3: "bcdhiklmnoprsuwz",
  4: "abcdhikmpswz",
  5: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne",
  5: "Strony"
};

