var searchData=
[
  ['wybor_5fpostaci_0',['wybor_postaci',['../wybor__postaci__z__menu_8cpp.html#a1af88d97dd905ce9c422715795e3b18c',1,'wybor_postaci(int bitmapa, RenderWindow &amp;window, RectangleShape &amp;chooseplayer1, RectangleShape &amp;chooseplayer2, Texture &amp;chooseplayer1_texture, Texture &amp;chooseplayer2_texture, int &amp;IdleAnim, int &amp;delay, int &amp;done):&#160;wybor_postaci_z_menu.cpp'],['../wybor__postaci__z__menu_8h.html#a1af88d97dd905ce9c422715795e3b18c',1,'wybor_postaci(int bitmapa, RenderWindow &amp;window, RectangleShape &amp;chooseplayer1, RectangleShape &amp;chooseplayer2, Texture &amp;chooseplayer1_texture, Texture &amp;chooseplayer2_texture, int &amp;IdleAnim, int &amp;delay, int &amp;done):&#160;wybor_postaci_z_menu.cpp']]]
];
