var searchData=
[
  ['atak_0',['atak',['../classzombie.html#a554c81def67cee97a5875443f3beead5',1,'zombie']]]
];
