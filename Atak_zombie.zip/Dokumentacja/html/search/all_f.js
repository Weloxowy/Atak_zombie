var searchData=
[
  ['update_5fhp_0',['update_hp',['../classzombie.html#a9356cdbb7d10e997f3e394cdc13feae6',1,'zombie::update_hp()'],['../classgracz.html#a567a955019653cc42aa8af10939f70d6',1,'gracz::update_hp()']]],
  ['update_5fhp_5fberserker_1',['update_hp_berserker',['../classgracz.html#a1189d390559e5030bbb8c9d3630d27a2',1,'gracz']]],
  ['usun_5fstrzale_5fz_5fpamieci_2',['usun_strzale_z_pamieci',['../classgracz.html#a0f485d51f887a6d29986d447af54cda5',1,'gracz']]]
];
