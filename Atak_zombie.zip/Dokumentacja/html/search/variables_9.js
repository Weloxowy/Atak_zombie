var searchData=
[
  ['score_0',['score',['../main_8cpp.html#aef160b7437d94056f1dc59646cd5b87d',1,'main.cpp']]],
  ['shape_1',['shape',['../classzombie.html#a7072b95bdc0934e7e163f4c1f2c1fb82',1,'zombie::shape()'],['../classstrzal.html#a7fe47034f434e1f6ae6c297795452a27',1,'strzal::shape()']]],
  ['spr_5fpozycje_5fzombie_2',['spr_pozycje_zombie',['../classzombie.html#a1915aeee89f97cfdb5668c1d87e4f080',1,'zombie']]],
  ['strzala_3',['strzala',['../classstrzal.html#af4386095b1e1089eb06f22f296fcf526',1,'strzal']]],
  ['szybkosc_5flotu_5fstrzaly_4',['szybkosc_lotu_strzaly',['../classstrzal.html#ab6faf22c90133631e3f5d6bc5f7999eb',1,'strzal']]]
];
