var searchData=
[
  ['ostateczne_5fpunkty_0',['ostateczne_punkty',['../main_8cpp.html#a154409f4cb8a43c37bd48c276fa7812e',1,'main.cpp']]]
];
