var searchData=
[
  ['bitmapa_0',['bitmapa',['../main_8cpp.html#a49f3e17259835b0bfba5bf73c90e8916',1,'main.cpp']]]
];
