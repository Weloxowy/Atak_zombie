var searchData=
[
  ['zombie_0',['zombie',['../classzombie.html#a754fb4d3a09ab51bfac94afc47e37cec',1,'zombie']]],
  ['zombie_5fpozycja_1',['zombie_pozycja',['../main_8cpp.html#ae2f5037db40719401e9756b3f7ac2b75',1,'main.cpp']]]
];
