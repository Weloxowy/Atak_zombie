var searchData=
[
  ['poziom_0',['poziom',['../main_8cpp.html#adf3f9636cdfb387bad5ffdef052bda59',1,'main.cpp']]],
  ['pozycja_1',['pozycja',['../main_8cpp.html#a5d7bc75d40aa91845c99e2eae27ce7db',1,'main.cpp']]]
];
