var searchData=
[
  ['klasa_5fpostac_2ecpp_0',['klasa_postac.cpp',['../klasa__postac_8cpp.html',1,'']]],
  ['klasa_5fpostac_2eh_1',['klasa_postac.h',['../klasa__postac_8h.html',1,'']]]
];
