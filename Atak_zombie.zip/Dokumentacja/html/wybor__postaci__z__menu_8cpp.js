var wybor__postaci__z__menu_8cpp =
[
    [ "wybor_postaci", "wybor__postaci__z__menu_8cpp.html#a1af88d97dd905ce9c422715795e3b18c", null ]
];