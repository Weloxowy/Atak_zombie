var pozycja__gracza_8cpp =
[
    [ "sprawdz_pozycje", "pozycja__gracza_8cpp.html#a475b039484d896dc7aa4aba0cb47505e", null ]
];