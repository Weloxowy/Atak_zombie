var cale__menu__lewy__klik_8cpp =
[
    [ "cale_menu", "cale__menu__lewy__klik_8cpp.html#a139a9bd377d8c04e6d9899b436f82457", null ],
    [ "laduj_zombie", "cale__menu__lewy__klik_8cpp.html#a09746e35d0a15455e00af95c10c53bc7", null ],
    [ "przyjmowanie_strzal", "cale__menu__lewy__klik_8cpp.html#afbb8cd6b13ec1ba2f2bb2c643e9fb308", null ]
];