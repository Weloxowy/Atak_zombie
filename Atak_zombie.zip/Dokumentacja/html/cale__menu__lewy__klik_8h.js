var cale__menu__lewy__klik_8h =
[
    [ "zombie", "classzombie.html", "classzombie" ],
    [ "cale_menu", "cale__menu__lewy__klik_8h.html#a139a9bd377d8c04e6d9899b436f82457", null ],
    [ "laduj_zombie", "cale__menu__lewy__klik_8h.html#a09746e35d0a15455e00af95c10c53bc7", null ],
    [ "przyjmowanie_strzal", "cale__menu__lewy__klik_8h.html#afbb8cd6b13ec1ba2f2bb2c643e9fb308", null ]
];