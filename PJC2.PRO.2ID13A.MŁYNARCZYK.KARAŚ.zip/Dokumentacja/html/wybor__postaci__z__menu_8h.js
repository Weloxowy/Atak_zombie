var wybor__postaci__z__menu_8h =
[
    [ "wybor_postaci", "wybor__postaci__z__menu_8h.html#a1af88d97dd905ce9c422715795e3b18c", null ]
];