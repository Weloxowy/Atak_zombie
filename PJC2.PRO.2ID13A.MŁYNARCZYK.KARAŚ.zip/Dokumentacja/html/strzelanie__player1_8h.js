var strzelanie__player1_8h =
[
    [ "strzal", "classstrzal.html", "classstrzal" ],
    [ "dodaj_strzale", "strzelanie__player1_8h.html#a6e2708f6a7531fc52993810e5d5e3af3", null ],
    [ "dodaj_strzale_dol", "strzelanie__player1_8h.html#a8c7725acfe016f11a0a51b2813decec1", null ],
    [ "dodaj_strzale_gora", "strzelanie__player1_8h.html#ab9ab79b3c41c2f7dc97e9e6dcb3e36f2", null ],
    [ "dodaj_strzale_lewo", "strzelanie__player1_8h.html#a6fbbd5c396f6fc0c96647f009cc66dcf", null ],
    [ "narysuj_strzale", "strzelanie__player1_8h.html#ae65fbfdb50f14c9ff4d4dee43b8012e0", null ],
    [ "narysuj_strzale_dol", "strzelanie__player1_8h.html#a14cb79e642b8c919f5870d6850e1c3b5", null ],
    [ "narysuj_strzale_gora", "strzelanie__player1_8h.html#add2296e87145ac6658373052e3be966e", null ],
    [ "narysuj_strzale_lewo", "strzelanie__player1_8h.html#a06e8c23b2075962ddb81b7d3682fb7a3", null ]
];