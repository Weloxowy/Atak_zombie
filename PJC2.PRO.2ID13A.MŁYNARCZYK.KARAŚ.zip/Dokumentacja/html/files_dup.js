var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "cale_menu_lewy_klik.cpp", "cale__menu__lewy__klik_8cpp.html", "cale__menu__lewy__klik_8cpp" ],
    [ "cale_menu_lewy_klik.h", "cale__menu__lewy__klik_8h.html", "cale__menu__lewy__klik_8h" ],
    [ "isAnyKeyPressed.cpp", "is_any_key_pressed_8cpp.html", "is_any_key_pressed_8cpp" ],
    [ "isAnyKeyPressed.h", "is_any_key_pressed_8h.html", "is_any_key_pressed_8h" ],
    [ "klasa_postac.cpp", "klasa__postac_8cpp.html", null ],
    [ "klasa_postac.h", "klasa__postac_8h.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "pozycja_gracza.cpp", "pozycja__gracza_8cpp.html", "pozycja__gracza_8cpp" ],
    [ "pozycja_gracza.h", "pozycja__gracza_8h.html", "pozycja__gracza_8h" ],
    [ "strzelanie_player1.cpp", "strzelanie__player1_8cpp.html", "strzelanie__player1_8cpp" ],
    [ "strzelanie_player1.h", "strzelanie__player1_8h.html", "strzelanie__player1_8h" ],
    [ "wybor_postaci_z_menu.cpp", "wybor__postaci__z__menu_8cpp.html", "wybor__postaci__z__menu_8cpp" ],
    [ "wybor_postaci_z_menu.h", "wybor__postaci__z__menu_8h.html", "wybor__postaci__z__menu_8h" ]
];