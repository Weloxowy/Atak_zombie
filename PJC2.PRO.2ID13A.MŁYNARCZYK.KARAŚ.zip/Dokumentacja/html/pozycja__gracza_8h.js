var pozycja__gracza_8h =
[
    [ "sprawdz_pozycje", "pozycja__gracza_8h.html#abf73cfbf3432b65b01fb3890bef55357", null ]
];