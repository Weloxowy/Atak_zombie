var annotated_dup =
[
    [ "gracz", "classgracz.html", "classgracz" ],
    [ "strzal", "classstrzal.html", "classstrzal" ],
    [ "zombie", "classzombie.html", "classzombie" ]
];