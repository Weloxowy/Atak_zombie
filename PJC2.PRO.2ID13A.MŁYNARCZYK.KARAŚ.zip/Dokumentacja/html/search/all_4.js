var searchData=
[
  ['gracz_0',['gracz',['../classgracz.html',1,'']]]
];
