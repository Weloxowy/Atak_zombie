var searchData=
[
  ['pozycja_5fgracza_2ecpp_0',['pozycja_gracza.cpp',['../pozycja__gracza_8cpp.html',1,'']]],
  ['pozycja_5fgracza_2eh_1',['pozycja_gracza.h',['../pozycja__gracza_8h.html',1,'']]]
];
