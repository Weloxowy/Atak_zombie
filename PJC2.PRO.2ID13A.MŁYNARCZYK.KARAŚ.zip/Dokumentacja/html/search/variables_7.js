var searchData=
[
  ['maxhp_0',['MAXhp',['../classzombie.html#a4b868c44539139fefee240d3a8f606aa',1,'zombie']]],
  ['maxhp_5fberserker_1',['MAXhp_berserker',['../classgracz.html#a0ad6d11046243f487eb119f81c09c7b4',1,'gracz']]],
  ['maxhp_5flucznik_2',['MAXhp_lucznik',['../classgracz.html#a843345d7cec6459c3aa80d167990b11a',1,'gracz']]]
];
