var searchData=
[
  ['kolizja_5fogolna_0',['kolizja_ogolna',['../classgracz.html#a7e9797a9a1572d0be7c24b104ddfdbab',1,'gracz']]],
  ['kolizja_5fstrzaly_1',['kolizja_strzaly',['../main_8cpp.html#af4327960a235ee29f00326aa5c2f158a',1,'main.cpp']]]
];
