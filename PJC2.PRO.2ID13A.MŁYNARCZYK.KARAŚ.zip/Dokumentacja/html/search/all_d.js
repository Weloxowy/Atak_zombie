var searchData=
[
  ['render_5fhp_0',['render_hp',['../classzombie.html#a9c2af90db5c101149caacc79e31b1add',1,'zombie::render_hp()'],['../classgracz.html#a9dcba2fd5edd0553e8a48adc1d2297d2',1,'gracz::render_hp()']]],
  ['respienie_5fzombie_1',['respienie_zombie',['../classzombie.html#af873da942450d1664e8dbd9c781f8a92',1,'zombie']]]
];
