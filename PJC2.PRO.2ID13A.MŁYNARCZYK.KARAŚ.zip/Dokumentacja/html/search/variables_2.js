var searchData=
[
  ['czas_5frespu_5fzombie_0',['czas_respu_zombie',['../main_8cpp.html#a4c627af561358316985314767df6b80d',1,'main.cpp']]],
  ['czy_5fsie_5frespi_1',['czy_sie_respi',['../classzombie.html#af0e20bf282741f73fb99e8609bdf9dc2',1,'zombie']]],
  ['czy_5fstrzela_2',['czy_strzela',['../main_8cpp.html#a40fdb8401d0ebf6f4c627b858b9d22f4',1,'main.cpp']]]
];
