var searchData=
[
  ['score_0',['score',['../main_8cpp.html#aef160b7437d94056f1dc59646cd5b87d',1,'main.cpp']]],
  ['shape_1',['shape',['../classzombie.html#a7072b95bdc0934e7e163f4c1f2c1fb82',1,'zombie::shape()'],['../classstrzal.html#a7fe47034f434e1f6ae6c297795452a27',1,'strzal::shape()']]],
  ['spr_5fpozycje_5fzombie_2',['spr_pozycje_zombie',['../classzombie.html#a1915aeee89f97cfdb5668c1d87e4f080',1,'zombie']]],
  ['sprawdz_5fpozycje_3',['sprawdz_pozycje',['../pozycja__gracza_8cpp.html#a475b039484d896dc7aa4aba0cb47505e',1,'sprawdz_pozycje(RectangleShape &amp;player, int pozycja, int &amp;IdleAnim, int &amp;delay, float &amp;hp):&#160;pozycja_gracza.cpp'],['../pozycja__gracza_8h.html#abf73cfbf3432b65b01fb3890bef55357',1,'sprawdz_pozycje(RectangleShape &amp;player, int pozycja, int &amp;IdleAnim, int &amp;dealy, float &amp;hp):&#160;pozycja_gracza.cpp']]],
  ['strzal_4',['strzal',['../classstrzal.html',1,'strzal'],['../classstrzal.html#af92a78b1d7ea652608e73ebb4ecd8418',1,'strzal::strzal(Texture *strzala, float szybkosc_lotu_strzaly, int dmg)']]],
  ['strzala_5',['strzala',['../classstrzal.html#af4386095b1e1089eb06f22f296fcf526',1,'strzal']]],
  ['strzelanie_6',['strzelanie',['../classgracz.html#a8871a02731c63081cd307448995e468e',1,'gracz']]],
  ['strzelanie_5fplayer1_2ecpp_7',['strzelanie_player1.cpp',['../strzelanie__player1_8cpp.html',1,'']]],
  ['strzelanie_5fplayer1_2eh_8',['strzelanie_player1.h',['../strzelanie__player1_8h.html',1,'']]],
  ['szybkosc_5flotu_5fstrzaly_9',['szybkosc_lotu_strzaly',['../classstrzal.html#ab6faf22c90133631e3f5d6bc5f7999eb',1,'strzal']]]
];
