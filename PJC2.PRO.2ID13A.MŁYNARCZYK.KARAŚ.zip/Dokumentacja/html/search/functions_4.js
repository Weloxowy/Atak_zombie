var searchData=
[
  ['inithp_0',['initHP',['../classzombie.html#a7e63c47d590ad6c42f99f3a7f6a454c5',1,'zombie::initHP()'],['../classgracz.html#aa1588fb740ca7da675cf36db12e73352',1,'gracz::initHP()']]],
  ['isanykeypressed_1',['isAnyKeyPressed',['../is_any_key_pressed_8cpp.html#a923658f32cdd59f0fd78c87245556898',1,'isAnyKeyPressed():&#160;isAnyKeyPressed.cpp'],['../is_any_key_pressed_8h.html#a923658f32cdd59f0fd78c87245556898',1,'isAnyKeyPressed():&#160;isAnyKeyPressed.cpp']]]
];
