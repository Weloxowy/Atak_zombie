var searchData=
[
  ['bitka_0',['bitka',['../classzombie.html#ada0b442f876d1c55d2a3f2bddcd3dbd0',1,'zombie']]]
];
