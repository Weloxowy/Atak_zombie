var searchData=
[
  ['sprawdz_5fpozycje_0',['sprawdz_pozycje',['../pozycja__gracza_8cpp.html#a475b039484d896dc7aa4aba0cb47505e',1,'sprawdz_pozycje(RectangleShape &amp;player, int pozycja, int &amp;IdleAnim, int &amp;delay, float &amp;hp):&#160;pozycja_gracza.cpp'],['../pozycja__gracza_8h.html#abf73cfbf3432b65b01fb3890bef55357',1,'sprawdz_pozycje(RectangleShape &amp;player, int pozycja, int &amp;IdleAnim, int &amp;dealy, float &amp;hp):&#160;pozycja_gracza.cpp']]],
  ['strzal_1',['strzal',['../classstrzal.html#af92a78b1d7ea652608e73ebb4ecd8418',1,'strzal']]],
  ['strzelanie_2',['strzelanie',['../classgracz.html#a8871a02731c63081cd307448995e468e',1,'gracz']]]
];
