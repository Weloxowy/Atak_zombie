var searchData=
[
  ['strzelanie_5fplayer1_2ecpp_0',['strzelanie_player1.cpp',['../strzelanie__player1_8cpp.html',1,'']]],
  ['strzelanie_5fplayer1_2eh_1',['strzelanie_player1.h',['../strzelanie__player1_8h.html',1,'']]]
];
