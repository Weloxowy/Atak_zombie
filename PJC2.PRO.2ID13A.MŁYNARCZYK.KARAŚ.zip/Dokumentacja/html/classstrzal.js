var classstrzal =
[
    [ "strzal", "classstrzal.html#af92a78b1d7ea652608e73ebb4ecd8418", null ],
    [ "dmg", "classstrzal.html#af081fb726d758afca1b4ab43187aaac3", null ],
    [ "shape", "classstrzal.html#a7fe47034f434e1f6ae6c297795452a27", null ],
    [ "strzala", "classstrzal.html#af4386095b1e1089eb06f22f296fcf526", null ],
    [ "szybkosc_lotu_strzaly", "classstrzal.html#ab6faf22c90133631e3f5d6bc5f7999eb", null ]
];