#include <SFML/Graphics.hpp>
#include <iostream>
#include <windows.h>
#include <math.h>


using namespace sf;
using namespace std;
/**
     *  @brief Funckja sprawdza czy  jakikolwiek przycisk jest wcisniety
     */
bool isAnyKeyPressed();
