#include <SFML/Graphics.hpp>
#include <iostream>
//#include <Animation.h>
#include <windows.h>
#include <math.h>


using namespace sf;
using namespace std;

bool isAnyKeyPressed();
